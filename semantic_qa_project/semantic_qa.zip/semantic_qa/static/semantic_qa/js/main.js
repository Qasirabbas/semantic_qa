// semantic_qa/static/semantic_qa/js/main.js

// Global utilities and common functionality
class SemanticQA {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupImageHandling();
        this.setupTooltips();
        this.setupLanguageSelector();
    }

    setupEventListeners() {
        // Handle form submissions
        document.addEventListener('submit', this.handleFormSubmit.bind(this));
        
        // Handle click events
        document.addEventListener('click', this.handleClicks.bind(this));
        
        // Handle search input
        const searchInputs = document.querySelectorAll('input[type="search"], input[name="q"]');
        searchInputs.forEach(input => {
            input.addEventListener('input', this.debounce(this.handleSearchInput.bind(this), 300));
        });
    }

    setupImageHandling() {
        // Setup image lazy loading
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        observer.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }

        // Setup image modal
        this.setupImageModal();
    }

    setupImageModal() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('result-image')) {
                this.openImageModal(e.target.src, e.target.alt);
            }
        });
    }

    openImageModal(src, alt) {
        const modal = document.createElement('div');
        modal.className = 'image-modal fade-in';
        modal.innerHTML = `
            <img src="${src}" alt="${alt}" class="slide-up">
            <div class="position-absolute top-0 end-0 p-3">
                <button class="btn btn-light btn-sm" onclick="this.closest('.image-modal').remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        document.body.appendChild(modal);
        
        // Close on escape
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                modal.remove();
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);
    }

    setupTooltips() {
        // Initialize Bootstrap tooltips
        if (typeof bootstrap !== 'undefined') {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
        }
    }

    setupLanguageSelector() {
        const languageLinks = document.querySelectorAll('.language-selector a');
        languageLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const lang = link.dataset.lang;
                this.changeLanguage(lang);
            });
        });
    }

    changeLanguage(lang) {
        const url = new URL(window.location);
        url.searchParams.set('lang', lang);
        window.location.href = url.toString();
    }

    handleFormSubmit(e) {
        const form = e.target;
        
        // Add loading state to submit buttons
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
            
            // Remove loading state after form submission
            setTimeout(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = submitBtn.dataset.originalText || 'Submit';
            }, 2000);
        }
    }

    handleClicks(e) {
        // Handle copy buttons
        if (e.target.classList.contains('copy-btn') || e.target.closest('.copy-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.copy-btn') || e.target;
            const textToCopy = btn.dataset.text || btn.getAttribute('data-text');
            this.copyToClipboard(textToCopy);
        }
        
        // Handle image toggle buttons
        if (e.target.classList.contains('toggle-image-btn')) {
            e.preventDefault();
            const resultId = e.target.dataset.resultId;
            this.toggleImage(resultId);
        }
    }

    handleSearchInput(e) {
        const query = e.target.value.trim();
        if (query.length > 2) {
            this.showSearchSuggestions(query, e.target);
        } else {
            this.hideSearchSuggestions();
        }
    }

    showSearchSuggestions(query, inputElement) {
        // Implementation for search suggestions
        // This would typically make an AJAX call to get suggestions
        console.log('Showing suggestions for:', query);
    }

    hideSearchSuggestions() {
        const suggestions = document.querySelector('.search-suggestions');
        if (suggestions) {
            suggestions.remove();
        }
    }

    toggleImage(resultId) {
        const container = document.getElementById(`image-container-${resultId}`);
        if (container) {
            if (container.style.display === 'none') {
                container.style.display = 'block';
                container.classList.add('fade-in');
            } else {
                container.style.display = 'none';
            }
        }
    }

    copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                this.showToast('Copied to clipboard!', 'success');
            }).catch(err => {
                this.showToast('Failed to copy', 'error');
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.opacity = '0';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                this.showToast('Copied to clipboard!', 'success');
            } catch (err) {
                this.showToast('Failed to copy', 'error');
            }
            
            document.body.removeChild(textArea);
        }
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed fade-in`;
        toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 250px;';
        toast.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'}-circle me-2"></i>
                ${message}
                <button type="button" class="btn-close ms-auto" onclick="this.closest('.alert').remove()"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Utility methods
    static formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    static formatDate(date) {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    }
}

// Search specific functionality
class SearchHandler {
    constructor() {
        this.apiUrl = '/api/search/';
        this.init();
    }

    init() {
        this.setupSearchForm();
        this.setupFilters();
    }

    setupSearchForm() {
        const searchForm = document.getElementById('searchForm');
        if (searchForm) {
            searchForm.addEventListener('submit', this.handleSearch.bind(this));
        }

        const ajaxSearchForm = document.getElementById('ajaxSearchForm');
        if (ajaxSearchForm) {
            ajaxSearchForm.addEventListener('submit', this.handleAjaxSearch.bind(this));
        }
    }

    setupFilters() {
        const filterInputs = document.querySelectorAll('.search-filter');
        filterInputs.forEach(input => {
            input.addEventListener('change', this.applyFilters.bind(this));
        });
    }

    async handleAjaxSearch(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        const query = formData.get('q');
        const language = formData.get('lang') || 'en';

        if (!query.trim()) {
            app.showToast('Please enter a search query', 'warning');
            return;
        }

        this.showSearchLoading(true);

        try {
            const response = await fetch(this.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    query: query,
                    language: language
                })
            });

            const data = await response.json();

            if (data.success) {
                this.displaySearchResults(data);
            } else {
                app.showToast(data.error || 'Search failed', 'error');
            }
        } catch (error) {
            console.error('Search error:', error);
            app.showToast('Search failed. Please try again.', 'error');
        } finally {
            this.showSearchLoading(false);
        }
    }

    displaySearchResults(data) {
        const resultsContainer = document.getElementById('searchResults');
        if (!resultsContainer) return;

        let html = `
            <div class="search-meta mb-3">
                <p class="text-muted">
                    Found ${data.total_results} results for "${data.query}" 
                    (${data.response_time.toFixed(3)}s)
                </p>
            </div>
        `;

        if (data.results.length === 0) {
            html += `
                <div class="text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4>No results found</h4>
                    <p class="text-muted">Try different keywords or check for typos.</p>
                </div>
            `;
        } else {
            data.results.forEach((result, index) => {
                html += this.createResultCard(result, index);
            });
        }

        resultsContainer.innerHTML = html;
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }

    createResultCard(result, index) {
        return `
            <div class="card result-card mb-4 slide-up" style="animation-delay: ${index * 0.1}s">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-${result.has_image ? '8' : '12'}">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-1">
                                        <span class="badge bg-primary me-2">${result.sku}</span>
                                        ${result.question}
                                    </h5>
                                    <div class="mb-2">
                                        <span class="badge bg-secondary me-1 match-type-badge">
                                            ${result.match_type}
                                        </span>
                                        <span class="badge bg-info me-1 match-type-badge">
                                            ${result.category || 'General'}
                                        </span>
                                        <span class="badge bg-success relevance-score">
                                            ${(result.relevance_score * 100).toFixed(1)}% relevance
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="answer-content">
                                <h6 class="text-muted mb-2">Answer:</h6>
                                <p class="card-text">${result.answer}</p>
                            </div>
                            
                            <div class="mt-3">
                                ${result.has_image ? `
                                    <button class="btn btn-sm btn-outline-info me-2 toggle-image-btn" 
                                            data-result-id="${result.id}">
                                        <i class="fas fa-image me-1"></i>Show/Hide Image
                                    </button>
                                ` : ''}
                                <button class="btn btn-sm btn-outline-secondary copy-btn" 
                                        data-text="SKU: ${result.sku}\nQ: ${result.question}\nA: ${result.answer}">
                                    <i class="fas fa-copy me-1"></i>Copy
                                </button>
                            </div>
                        </div>
                        
                        ${result.has_image ? `
                            <div class="col-md-4">
                                <div class="image-container" id="image-container-${result.id}">
                                    <img src="${result.image_link}" 
                                         alt="Image for ${result.sku}"
                                         class="img-fluid result-image"
                                         loading="lazy"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                    <div class="text-center p-3 bg-light" style="display: none;">
                                        <i class="fas fa-image text-muted"></i>
                                        <p class="text-muted small mb-0">Image unavailable</p>
                                    </div>
                                </div>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    showSearchLoading(show) {
        const searchBtn = document.querySelector('#ajaxSearchForm button[type="submit"]');
        const resultsContainer = document.getElementById('searchResults');

        if (show) {
            if (searchBtn) {
                searchBtn.disabled = true;
                searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Searching...';
            }
            if (resultsContainer) {
                resultsContainer.innerHTML = '<div class="text-center py-5"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            }
        } else {
            if (searchBtn) {
                searchBtn.disabled = false;
                searchBtn.innerHTML = '<i class="fas fa-search me-2"></i>Search';
            }
        }
    }

    getCSRFToken() {
        const token = document.querySelector('[name=csrfmiddlewaretoken]');
        return token ? token.value : '';
    }

    applyFilters() {
        // Implementation for applying search filters
        console.log('Applying filters...');
    }
}

// File upload handler
class FileUploadHandler {
    constructor() {
        this.init();
    }

    init() {
        this.setupFileInput();
        this.setupDragAndDrop();
    }

    setupFileInput() {
        const fileInputs = document.querySelectorAll('input[type="file"]');
        fileInputs.forEach(input => {
            input.addEventListener('change', this.handleFileSelect.bind(this));
        });
    }

    setupDragAndDrop() {
        const dropZones = document.querySelectorAll('.file-drop-zone');
        dropZones.forEach(zone => {
            zone.addEventListener('dragover', this.handleDragOver.bind(this));
            zone.addEventListener('dragenter', this.handleDragEnter.bind(this));
            zone.addEventListener('dragleave', this.handleDragLeave.bind(this));
            zone.addEventListener('drop', this.handleDrop.bind(this));
        });
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.validateAndPreviewFile(file, e.target);
        }
    }

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    handleDragEnter(e) {
        e.preventDefault();
        e.stopPropagation();
        e.target.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        e.target.classList.remove('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        e.target.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const fileInput = e.target.querySelector('input[type="file"]');
            if (fileInput) {
                fileInput.files = files;
                this.validateAndPreviewFile(files[0], fileInput);
            }
        }
    }

    validateAndPreviewFile(file, input) {
        // Validate file type
        const allowedTypes = input.accept ? input.accept.split(',').map(t => t.trim()) : ['.xlsx', '.xls'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        
        if (!allowedTypes.includes(fileExtension)) {
            app.showToast(`Invalid file type. Allowed: ${allowedTypes.join(', ')}`, 'error');
            input.value = '';
            return;
        }

        // Validate file size (10MB limit)
        if (file.size > 10 * 1024 * 1024) {
            app.showToast('File size must be less than 10MB', 'error');
            input.value = '';
            return;
        }

        // Show file preview
        this.showFilePreview(file, input);
    }

    showFilePreview(file, input) {
        const previewContainer = input.closest('.form-group')?.querySelector('.file-preview');
        if (previewContainer) {
            previewContainer.innerHTML = `
                <div class="file-info p-3 border rounded">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-file-excel text-success me-2"></i>
                        <div>
                            <div class="fw-bold">${file.name}</div>
                            <small class="text-muted">${SemanticQA.formatFileSize(file.size)}</small>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-danger ms-auto" 
                                onclick="this.closest('.file-info').remove(); document.querySelector('input[type=file]').value='';">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `;
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.app = new SemanticQA();
    window.searchHandler = new SearchHandler();
    window.fileUploadHandler = new FileUploadHandler();
    
    // Add smooth scrolling to anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(() => {
        document.querySelectorAll('.alert:not(.alert-permanent)').forEach(alert => {
            if (alert.querySelector('.btn-close')) {
                alert.querySelector('.btn-close').click();
            }
        });
    }, 5000);
});