import logging
import time
import re
from typing import List, Dict, Optional
from django.conf import settings

# Updated imports for ChatGLM and Hugging Face embeddings
import openai
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableParallel, RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_community.embeddings import HuggingFaceEmbeddings
from sentence_transformers import SentenceTransformer
import numpy as np

from .models import QAEntry, SemanticQuery, QueryMatch, Translation, SystemConfig
from .utils import SearchQueryProcessor, get_client_ip

logger = logging.getLogger('semantic_qa')

class ChatGLMInterface:
    """Interface for ChatGLM API using OpenAI-compatible format"""
    
    def __init__(self):
        self.client = openai.OpenAI(
            api_key="a74b8073a98d4da4a066fc72095f58b0.gulObfhh7fnNcAmp",
            base_url="https://open.bigmodel.cn/api/paas/v4/"
        )
        self.model_name = "glm-4-flash"
    
    def invoke(self, prompt: str) -> str:
        """Send request to ChatGLM and return response"""
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2048
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"ChatGLM API error: {str(e)}")
            raise e

class ChatGLMChain:
    """LangChain-compatible wrapper for ChatGLM"""
    
    def __init__(self, llm_interface: ChatGLMInterface):
        self.llm = llm_interface
    
    def invoke(self, inputs: dict) -> str:
        """Process inputs and call ChatGLM"""
        # Extract the formatted prompt from inputs
        if isinstance(inputs, dict) and 'text' in inputs:
            prompt = inputs['text']
        else:
            prompt = str(inputs)
        
        return self.llm.invoke(prompt)

class SemanticSearchService:
    """Enhanced service for performing semantic search with ChatGLM and Hugging Face embeddings"""
    
    def __init__(self):
        self.embeddings = None
        self.llm = None
        self.vector_store = None
        self.query_processor = SearchQueryProcessor()
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize ChatGLM and Hugging Face embedding models"""
        try:
            # Initialize ChatGLM
            self.chatglm_interface = ChatGLMInterface()
            self.llm = ChatGLMChain(self.chatglm_interface)
            logger.info("Successfully initialized ChatGLM (glm-4-flash)")
            
            # Initialize multilingual embeddings from Hugging Face
            # Using a model that works well for both English and Chinese
            model_name = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
            logger.info(f"Loading embeddings model: {model_name}")
            
            self.embeddings = HuggingFaceEmbeddings(
                model_name=model_name,
                model_kwargs={'device': 'cpu'},  # Use 'cuda' if GPU is available
                encode_kwargs={'normalize_embeddings': True}  # Important for similarity
            )
            
            logger.info("Successfully initialized Hugging Face embeddings")
            
            # Test the models
            try:
                # Test embeddings
                test_embedding = self.embeddings.embed_query("test")
                logger.info(f"Embeddings test successful: {len(test_embedding)} dimensions")
                
                # Test ChatGLM
                test_response = self.llm.invoke("Respond with just 'OK'")
                logger.info(f"ChatGLM test successful: {test_response[:50]}")
                
            except Exception as test_error:
                logger.warning(f"Model test failed: {str(test_error)}")
            
        except Exception as e:
            logger.error(f"Failed to initialize models: {str(e)}")
            # Set to None so system falls back to keyword search
            self.embeddings = None
            self.llm = None
    
    def search_qa_entries(self, query: str, user_ip: str = None, user_agent: str = None) -> Dict:
        """
        Enhanced search with minimum similarity threshold and comprehensive results
        """
        start_time = time.time()
        
        try:
            logger.info(f"🔍 Starting search for query: '{query}'")
            
            # Check if we have any entries to search
            total_entries = QAEntry.objects.count()
            logger.info(f"📊 Total QA entries in database: {total_entries}")
            
            if total_entries == 0:
                logger.warning("❌ No QA entries found in database!")
                return {
                    'query': query,
                    'processed_query': query,
                    'query_type': 'no_data',
                    'results': [],
                    'total_results': 0,
                    'response_time': time.time() - start_time,
                    'error': 'No QA entries in database'
                }
            
            # Clean and process query
            cleaned_query = self.query_processor.clean_query(query)
            extracted_skus = self.query_processor.extract_skus(query)
            semantic_terms = self.query_processor.extract_semantic_terms(cleaned_query)
            
            logger.info(f"🧹 Cleaned query: '{cleaned_query}'")
            logger.info(f"🏷️  Extracted SKUs: {extracted_skus}")
            logger.info(f"🔤 Semantic terms: {semantic_terms}")
            
            results = []
            query_type = 'semantic'
            
            # Strategy 1: Exact SKU match
            if extracted_skus:
                logger.info(f"🎯 Trying exact SKU search for: {extracted_skus}")
                exact_matches = self._search_by_sku(extracted_skus, exact=True)
                if exact_matches:
                    logger.info(f"✅ Found {len(exact_matches)} exact SKU matches")
                    results.extend(exact_matches)
                    query_type = 'exact_sku'
                else:
                    logger.info("❌ No exact SKU matches found")
            
            # Strategy 2: Partial SKU match
            if not results and extracted_skus:
                logger.info(f"🔍 Trying partial SKU search for: {extracted_skus}")
                partial_matches = self._search_by_sku(extracted_skus, exact=False)
                if partial_matches:
                    logger.info(f"✅ Found {len(partial_matches)} partial SKU matches")
                    results.extend(partial_matches)
                    query_type = 'partial_sku'
                else:
                    logger.info("❌ No partial SKU matches found")
            
            # Strategy 3: Enhanced semantic search with minimum threshold
            if self.embeddings and self.llm:
                logger.info("🧠 Performing semantic search with ChatGLM and Hugging Face embeddings...")
                try:
                    semantic_matches = self._enhanced_semantic_search(cleaned_query)
                    if semantic_matches:
                        logger.info(f"✅ Found {len(semantic_matches)} semantic matches")
                        if not results:  # Only use semantic if no exact matches
                            results.extend(semantic_matches)
                            query_type = 'semantic'
                        else:
                            # Combine with existing results, removing duplicates
                            results = self._merge_results(results, semantic_matches)
                    else:
                        logger.info("❌ No semantic matches found")
                except Exception as e:
                    logger.error(f"❌ Semantic search failed: {str(e)}")
                    # Fall through to keyword search
            else:
                logger.warning("⚠️ Semantic search not available (models not initialized)")
            
            # Strategy 4: Keyword-based search (always include)
            logger.info(f"🔍 Adding keyword search results with terms: {semantic_terms}")
            keyword_matches = self._keyword_search(semantic_terms)
            if keyword_matches:
                logger.info(f"✅ Found {len(keyword_matches)} keyword matches")
                if not results:
                    results.extend(keyword_matches)
                    query_type = 'keyword'
                else:
                    # Merge keyword results
                    results = self._merge_results(results, keyword_matches)
            
            # Remove duplicates and sort by relevance
            results = self._deduplicate_results(results)
            results = sorted(results, key=lambda x: x['score'], reverse=True)
            
            logger.info(f"🧹 After deduplication and sorting: {len(results)} results")
            
            # Set a generous limit but keep all high-quality results
            max_results = 50  # Increased limit to show more results
            if len(results) > max_results:
                results = results[:max_results]
                logger.info(f"📊 Limited to top {max_results} results")
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Log the query
            self._log_query(query, cleaned_query, query_type, user_ip, user_agent, response_time, results)
            
            # Log final summary
            if results:
                logger.info(f"🎉 Search completed successfully: {len(results)} results in {response_time:.3f}s")
                for i, result in enumerate(results[:5]):  # Log first 5 results
                    logger.info(f"   Result {i+1}: {result['entry'].sku} - {result['match_type']} - Score: {result['score']:.3f}")
            else:
                logger.warning(f"😔 Search returned no results for query: '{query}'")
                # Still try to provide some results with very low threshold
                if self.embeddings:
                    fallback_results = self._fallback_search(cleaned_query)
                    if fallback_results:
                        results = fallback_results
                        logger.info(f"💡 Fallback search found {len(results)} results")
            
            return {
                'query': query,
                'processed_query': cleaned_query,
                'query_type': query_type,
                'results': results,
                'total_results': len(results),
                'response_time': response_time
            }
            
        except Exception as e:
            logger.error(f"❌ Search error: {str(e)}")
            return {
                'query': query,
                'processed_query': query,
                'query_type': 'error',
                'results': [],
                'total_results': 0,
                'response_time': time.time() - start_time,
                'error': str(e)
            }
    
    def _enhanced_semantic_search(self, query: str, min_threshold: float = 0.1) -> List[Dict]:
        """Enhanced semantic search with very low threshold to show all possible matches"""
        try:
            logger.info(f"🧠 Starting enhanced semantic search for: '{query}'")
            
            # Get all QA entries
            entries = QAEntry.objects.all()
            
            if not entries:
                logger.info("❌ No QA entries found for semantic search")
                return []
            
            logger.info(f"📊 Processing {len(entries)} entries for semantic search")
            
            # Create documents for vector search
            documents = []
            entry_mapping = {}
            
            for entry in entries:
                # Create comprehensive document text for better matching
                doc_parts = []
                
                # Add SKU with special formatting
                doc_parts.append(f"Product: {entry.sku}")
                
                # Add question
                doc_parts.append(f"Question: {entry.question}")
                
                # Add answer
                doc_parts.append(f"Answer: {entry.answer}")
                
                # Add category if available
                if entry.category:
                    doc_parts.append(f"Category: {entry.category}")
                
                # Add keywords if available
                if entry.keywords:
                    doc_parts.append(f"Keywords: {entry.keywords}")
                
                doc_text = " | ".join(doc_parts)
                documents.append(doc_text)
                entry_mapping[len(documents) - 1] = entry
                logger.debug(f"📄 Document {len(documents)}: {doc_text[:100]}...")
            
            # Create vector store using FAISS
            if len(documents) > 0:
                try:
                    from langchain.schema import Document
                    doc_objects = [Document(page_content=doc) for doc in documents]
                    
                    logger.info(f"🔧 Creating FAISS vector store with {len(doc_objects)} documents")
                    vector_store = FAISS.from_documents(doc_objects, self.embeddings)
                    
                    # Use very low threshold to capture all possible matches
                    similarity_threshold = min_threshold
                    logger.info(f"🎯 Using minimum similarity threshold: {similarity_threshold}")
                    
                    # Perform similarity search with larger k to get more results
                    logger.info(f"🔍 Performing similarity search for: '{query}'")
                    search_results = vector_store.similarity_search_with_score(query, k=len(documents))
                    
                    logger.info(f"📊 Raw search results: {len(search_results)} matches")
                    
                    results = []
                    for i, (doc, score) in enumerate(search_results):
                        logger.debug(f"   Result {i+1}: Score={score:.4f}, Doc='{doc.page_content[:100]}...'")
                        
                        # Find corresponding entry
                        try:
                            doc_index = documents.index(doc.page_content)
                            entry = entry_mapping[doc_index]
                            
                            # Convert distance to similarity (lower distance = higher similarity)
                            # For cosine distance: similarity = 1 - (distance / 2)
                            # Ensure we get a value between 0 and 1
                            if score <= 0:
                                similarity_score = 1.0
                            elif score >= 2:
                                similarity_score = 0.0
                            else:
                                similarity_score = 1.0 - (score / 2.0)
                            
                            # Apply very lenient threshold to show most results
                            if similarity_score >= similarity_threshold:
                                results.append({
                                    'entry': entry,
                                    'score': similarity_score,
                                    'match_type': 'semantic',
                                    'match_reason': f'Semantic similarity: {similarity_score:.3f}'
                                })
                                logger.debug(f"   ✅ Added result: {entry.sku} - Score: {similarity_score:.3f}")
                            else:
                                logger.debug(f"   ❌ Below threshold: {similarity_score:.3f} < {similarity_threshold}")
                        
                        except ValueError as e:
                            logger.error(f"   ❌ Error mapping document: {str(e)}")
                            continue
                    
                    logger.info(f"🎉 Semantic search completed: {len(results)} results above threshold")
                    return sorted(results, key=lambda x: x['score'], reverse=True)
                    
                except Exception as e:
                    logger.error(f"❌ FAISS vector store error: {str(e)}")
                    return []
            
            else:
                logger.warning("❌ No documents to search")
                return []
                
        except Exception as e:
            logger.error(f"❌ Enhanced semantic search error: {str(e)}")
            import traceback
            logger.error(f"Full traceback: {traceback.format_exc()}")
            return []
    
    def _fallback_search(self, query: str) -> List[Dict]:
        """Fallback search with extremely low threshold to always return some results"""
        try:
            logger.info(f"💡 Performing fallback search with minimal threshold")
            return self._enhanced_semantic_search(query, min_threshold=0.01)  # Very low threshold
        except Exception as e:
            logger.error(f"❌ Fallback search failed: {str(e)}")
            return []
    
    def _search_by_sku(self, skus: List[str], exact: bool = True) -> List[Dict]:
        """Search by SKU with exact or partial matching"""
        results = []
        
        for sku in skus:
            if exact:
                entries = QAEntry.objects.filter(sku__iexact=sku)
            else:
                entries = QAEntry.objects.filter(sku__icontains=sku)
            
            for entry in entries:
                results.append({
                    'entry': entry,
                    'score': 1.0 if exact else 0.9,
                    'match_type': 'exact_sku' if exact else 'partial_sku',
                    'match_reason': f'SKU match: {sku}'
                })
        
        return results
    
    def _keyword_search(self, terms: List[str]) -> List[Dict]:
        """Enhanced keyword-based search"""
        if not terms:
            return []
        
        from django.db.models import Q
        
        # Build query for searching in multiple fields
        query = Q()
        for term in terms:
            query |= (
                Q(question__icontains=term) |
                Q(answer__icontains=term) |
                Q(keywords__icontains=term) |
                Q(sku__icontains=term) |
                Q(category__icontains=term)
            )
        
        entries = QAEntry.objects.filter(query).distinct()
        
        results = []
        for entry in entries:
            # Calculate relevance score based on term matches
            score = self._calculate_keyword_score(entry, terms)
            results.append({
                'entry': entry,
                'score': score * 0.8,  # Lower than semantic scores
                'match_type': 'keyword',
                'match_reason': f'Keyword match: {", ".join(terms)}'
            })
        
        return sorted(results, key=lambda x: x['score'], reverse=True)
    
    def _calculate_keyword_score(self, entry: QAEntry, terms: List[str]) -> float:
        """Enhanced relevance score calculation for keyword matching"""
        # Combine all searchable text
        text_fields = {
            'sku': entry.sku,
            'question': entry.question,
            'answer': entry.answer,
            'keywords': entry.keywords or '',
            'category': entry.category or ''
        }
        
        total_score = 0
        max_possible_score = 0
        
        for term in terms:
            term_lower = term.lower()
            term_score = 0
            
            # Weight different fields differently
            field_weights = {
                'sku': 2.0,      # SKU matches are very important
                'question': 1.5,  # Question matches are important
                'answer': 1.0,    # Answer matches are standard
                'keywords': 1.2,  # Keyword matches are slightly more important
                'category': 0.8   # Category matches are less important
            }
            
            for field_name, field_value in text_fields.items():
                if field_value:
                    field_lower = field_value.lower()
                    count = field_lower.count(term_lower)
                    if count > 0:
                        term_score += count * field_weights[field_name]
            
            total_score += term_score
            max_possible_score += max(field_weights.values())
        
        # Normalize score
        if max_possible_score > 0:
            normalized_score = min(total_score / max_possible_score, 1.0)
        else:
            normalized_score = 0.0
        
        return normalized_score
    
    def _merge_results(self, primary_results: List[Dict], secondary_results: List[Dict]) -> List[Dict]:
        """Merge two result sets, avoiding duplicates and maintaining scores"""
        # Create a map of existing entries
        existing_entries = {result['entry'].id: result for result in primary_results}
        
        # Add secondary results that don't already exist, or update scores if better
        for secondary_result in secondary_results:
            entry_id = secondary_result['entry'].id
            
            if entry_id not in existing_entries:
                # Add new result
                primary_results.append(secondary_result)
            else:
                # Update existing result if secondary has better score
                existing_result = existing_entries[entry_id]
                if secondary_result['score'] > existing_result['score']:
                    existing_result['score'] = secondary_result['score']
                    existing_result['match_type'] = f"{existing_result['match_type']}+{secondary_result['match_type']}"
                    existing_result['match_reason'] = f"{existing_result['match_reason']} | {secondary_result['match_reason']}"
        
        return primary_results
    
    def _deduplicate_results(self, results: List[Dict]) -> List[Dict]:
        """Remove duplicate entries from results"""
        seen_entries = set()
        deduplicated = []
        
        for result in results:
            entry_id = result['entry'].id
            if entry_id not in seen_entries:
                seen_entries.add(entry_id)
                deduplicated.append(result)
        
        return deduplicated
    
    def _log_query(self, original_query: str, processed_query: str, query_type: str, 
                   user_ip: str, user_agent: str, response_time: float, results: List[Dict]):
        """Log search query and results"""
        try:
            # Create query log
            query_log = SemanticQuery.objects.create(
                query_text=original_query,
                processed_query=processed_query,
                query_type=query_type,
                user_ip=user_ip,
                user_agent=user_agent or '',
                response_time=response_time
            )
            
            # Log matches
            for result in results:
                QueryMatch.objects.create(
                    query=query_log,
                    qa_entry=result['entry'],
                    relevance_score=result['score'],
                    match_reason=result['match_reason']
                )
            
        except Exception as e:
            logger.error(f"Failed to log query: {str(e)}")

class TranslationService:
    """Enhanced translation service using ChatGLM"""
    
    def __init__(self):
        self.llm = None
        self._initialize_model()
    
    def _initialize_model(self):
        """Initialize ChatGLM for translation"""
        try:
            self.chatglm_interface = ChatGLMInterface()
            self.llm = ChatGLMChain(self.chatglm_interface)
            logger.info("Successfully initialized ChatGLM for translation")
        except Exception as e:
            logger.error(f"Failed to initialize translation model: {str(e)}")
    
    def translate_text(self, text: str, target_language: str, source_language: str = 'en') -> str:
        """Translate text using ChatGLM"""
        if not self.llm or source_language == target_language:
            return text
        
        try:
            # Check cache first
            cached_translation = self._get_cached_translation(text, source_language, target_language)
            if cached_translation:
                return cached_translation
            
            # Create translation prompt
            language_names = {
                'en': 'English',
                'zh': 'Chinese',
                'es': 'Spanish',
                'fr': 'French',
                'de': 'German',
                'ja': 'Japanese'
            }
            
            source_lang_name = language_names.get(source_language, source_language)
            target_lang_name = language_names.get(target_language, target_language)
            
            prompt = f"""Translate the following {source_lang_name} text to {target_lang_name}. 
Only provide the translation, no explanations or additional text:

{text}"""
            
            translated_text = self.llm.invoke(prompt)
            
            # Cache the translation
            self._cache_translation(text, translated_text, source_language, target_language)
            
            return translated_text.strip()
            
        except Exception as e:
            logger.error(f"Translation error: {str(e)}")
            return text  # Return original text if translation fails
    
    def translate_qa_result(self, search_result: Dict, target_language: str) -> Dict:
        """Translate search results to target language"""
        if target_language == 'en' or not self.llm:
            return search_result
        
        try:
            translated_results = []
            
            for result in search_result.get('results', []):
                entry = result['entry']
                
                # Translate question and answer
                translated_question = self.translate_text(entry.question, target_language)
                translated_answer = self.translate_text(entry.answer, target_language)
                
                # Create a copy of the result with translated content
                translated_result = result.copy()
                translated_result['entry'] = type('TranslatedEntry', (), {
                    'id': entry.id,
                    'sku': entry.sku,  # Don't translate SKU
                    'question': translated_question,
                    'answer': translated_answer,
                    'image_link': entry.image_link,
                    'category': entry.category,
                    'keywords': entry.keywords
                })()
                
                translated_results.append(translated_result)
            
            # Update the search result
            search_result = search_result.copy()
            search_result['results'] = translated_results
            
            return search_result
            
        except Exception as e:
            logger.error(f"Result translation error: {str(e)}")
            return search_result
    
    def _get_cached_translation(self, text: str, source_lang: str, target_lang: str) -> Optional[str]:
        """Get cached translation if available"""
        try:
            import hashlib
            text_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
            translation = Translation.objects.get(
                source_text_hash=text_hash,
                source_language=source_lang,
                target_language=target_lang
            )
            return translation.translated_text
        except Translation.DoesNotExist:
            return None
    
    def _cache_translation(self, text: str, translated_text: str, source_lang: str, target_lang: str):
        """Cache translation for future use"""
        try:
            import hashlib
            text_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
            Translation.objects.get_or_create(
                source_text_hash=text_hash,
                source_language=source_lang,
                target_language=target_lang,
                defaults={
                    'source_text': text,
                    'translated_text': translated_text,
                    'translation_service': 'chatglm'
                }
            )
        except Exception as e:
            logger.error(f"Failed to cache translation: {str(e)}")