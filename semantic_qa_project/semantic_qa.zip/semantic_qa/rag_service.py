# semantic_qa/rag_service.py
import logging
import time
import numpy as np
from typing import List, Dict, Optional, Tuple
from django.db.models import Q
from django.conf import settings

from langchain_community.vectorstores import FAISS
from langchain.schema import Document as LangchainDocument
from langchain_core.prompts import ChatPromptTemplate
import openai

from .models import QAEntry, TextChunk, Document, SemanticQuery, QueryMatch
from .utils import SearchQueryProcessor, get_client_ip

logger = logging.getLogger('semantic_qa')

class RAGService:
    """Enhanced RAG service with document search and generation"""
    
    def __init__(self):
        self.query_processor = SearchQueryProcessor()
        self.chatglm_client = None
        self.embeddings = None
        self.vector_store = None
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize ChatGLM and embeddings"""
        try:
            # Initialize ChatGLM client
            self.chatglm_client = openai.OpenAI(
                api_key="a74b8073a98d4da4a066fc72095f58b0.gulObfhh7fnNcAmp",
                base_url="https://open.bigmodel.cn/api/paas/v4/"
            )
            
            # Initialize embeddings
            from langchain_community.embeddings import HuggingFaceEmbeddings
            self.embeddings = HuggingFaceEmbeddings(
                model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                model_kwargs={'device': 'cpu'},
                encode_kwargs={'normalize_embeddings': True}
            )
            
            logger.info("✅ RAG service initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize RAG service: {str(e)}")
    
    def enhanced_search(self, query: str, document_types: List[str] = None, 
                       use_rag: bool = True, max_results: int = 10,
                       user_ip: str = None, user_agent: str = None) -> Dict:
        """Enhanced search with RAG capabilities"""
        start_time = time.time()
        
        try:
            logger.info(f"🔍 Enhanced search for: '{query}'")
            
            # Clean and process query
            cleaned_query = self.query_processor.clean_query(query)
            extracted_skus = self.query_processor.extract_skus(query)
            semantic_terms = self.query_processor.extract_semantic_terms(cleaned_query)
            
            # Determine search strategy
            search_results = []
            query_type = 'hybrid'
            
            # 1. Traditional QA search (existing functionality)
            qa_results = self._search_qa_entries(cleaned_query, extracted_skus, semantic_terms)
            search_results.extend(qa_results)
            
            # 2. Document search if requested
            if document_types is None:
                document_types = ['pdf', 'image', 'link']
            
            if document_types:
                doc_results = self._search_documents(cleaned_query, semantic_terms, document_types)
                search_results.extend(doc_results)
            
            # 3. RAG generation if enabled and we have context
            generated_answer = ""
            rag_context = ""
            
            if use_rag and (search_results or self._has_relevant_chunks(cleaned_query)):
                rag_result = self._generate_rag_answer(cleaned_query, search_results)
                generated_answer = rag_result['answer']
                rag_context = rag_result['context']
                query_type = 'rag'
            
            # Sort and limit results
            search_results = self._rank_and_limit_results(search_results, max_results)
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Log the query
            query_log = self._log_enhanced_query(
                query, cleaned_query, query_type, document_types, use_rag,
                len(search_results), rag_context, generated_answer,
                user_ip, user_agent, response_time
            )
            
            # Log matches
            self._log_query_matches(query_log, search_results)
            
            return {
                'query': query,
                'processed_query': cleaned_query,
                'query_type': query_type,
                'results': search_results,
                'total_results': len(search_results),
                'response_time': response_time,
                'generated_answer': generated_answer,
                'rag_context_used': bool(rag_context),
                'document_types_searched': document_types,
                'success': True
            }
            
        except Exception as e:
            logger.error(f"❌ Enhanced search error: {str(e)}")
            return {
                'query': query,
                'processed_query': query,
                'query_type': 'error',
                'results': [],
                'total_results': 0,
                'response_time': time.time() - start_time,
                'generated_answer': '',
                'rag_context_used': False,
                'document_types_searched': document_types or [],
                'success': False,
                'error': str(e)
            }
    
    def _search_qa_entries(self, query: str, skus: List[str], terms: List[str]) -> List[Dict]:
        """Search traditional QA entries"""
        results = []
        
        try:
            # Exact SKU match
            if skus:
                for sku in skus:
                    entries = QAEntry.objects.filter(sku__iexact=sku)
                    for entry in entries:
                        results.append({
                            'type': 'qa_entry',
                            'source': 'qa_database',
                            'entry': entry,
                            'score': 1.0,
                            'match_type': 'exact_sku',
                            'match_reason': f'Exact SKU match: {sku}',
                            'text_content': f"Q: {entry.question}\nA: {entry.answer}",
                            'source_info': {
                                'sku': entry.sku,
                                'category': entry.category
                            }
                        })
            
            # Semantic search on QA entries
            if self.embeddings and terms:
                qa_semantic_results = self._semantic_search_qa_entries(query, terms)
                results.extend(qa_semantic_results)
            
            # Keyword search fallback
            if terms:
                keyword_results = self._keyword_search_qa_entries(terms)
                results.extend(keyword_results)
            
        except Exception as e:
            logger.error(f"❌ QA search error: {str(e)}")
        
        return results
    
    def _search_documents(self, query: str, terms: List[str], document_types: List[str]) -> List[Dict]:
        """Search document chunks"""
        results = []
        
        try:
            # Get completed documents of specified types
            documents = Document.objects.filter(
                document_type__in=document_types,
                processing_status='completed'
            )
            
            if not documents.exists():
                logger.info("ℹ️ No processed documents found for search")
                return results
            
            # Semantic search on document chunks
            if self.embeddings and terms:
                chunk_results = self._semantic_search_chunks(query, terms, documents)
                results.extend(chunk_results)
            
            # Keyword search on documents
            keyword_doc_results = self._keyword_search_documents(terms, documents)
            results.extend(keyword_doc_results)
            
        except Exception as e:
            logger.error(f"❌ Document search error: {str(e)}")
        
        return results
    
    def _semantic_search_qa_entries(self, query: str, terms: List[str]) -> List[Dict]:
        """Semantic search on QA entries using embeddings"""
        results = []
        
        try:
            # Get all QA entries
            qa_entries = QAEntry.objects.all()
            
            if not qa_entries.exists():
                return results
            
            # Create documents for vector search
            documents = []
            entry_mapping = {}
            
            for entry in qa_entries:
                doc_text = f"SKU: {entry.sku}\nQuestion: {entry.question}\nAnswer: {entry.answer}"
                if entry.category:
                    doc_text += f"\nCategory: {entry.category}"
                if entry.keywords:
                    doc_text += f"\nKeywords: {entry.keywords}"
                
                documents.append(LangchainDocument(page_content=doc_text))
                entry_mapping[len(documents) - 1] = entry
            
            # Create vector store
            vector_store = FAISS.from_documents(documents, self.embeddings)
            
            # Search
            search_results = vector_store.similarity_search_with_score(query, k=20)
            
            for doc, score in search_results:
                # Convert distance to similarity
                similarity = 1.0 - (score / 2.0) if score <= 2.0 else 0.0
                
                if similarity >= 0.1:  # Minimum threshold
                    doc_index = documents.index(doc)
                    entry = entry_mapping[doc_index]
                    
                    results.append({
                        'type': 'qa_entry',
                        'source': 'qa_database',
                        'entry': entry,
                        'score': similarity,
                        'match_type': 'semantic',
                        'match_reason': f'Semantic similarity: {similarity:.3f}',
                        'text_content': f"Q: {entry.question}\nA: {entry.answer}",
                        'source_info': {
                            'sku': entry.sku,
                            'category': entry.category
                        }
                    })
            
        except Exception as e:
            logger.error(f"❌ Semantic QA search error: {str(e)}")
        
        return results
    
    def _semantic_search_chunks(self, query: str, terms: List[str], documents) -> List[Dict]:
        """Semantic search on document text chunks"""
        results = []
        
        try:
            # Get text chunks from specified documents
            chunks = TextChunk.objects.filter(
                document__in=documents
            ).select_related('document')
            
            if not chunks.exists():
                logger.info("ℹ️ No text chunks found for semantic search")
                return results
            
            # Create documents for vector search
            chunk_documents = []
            chunk_mapping = {}
            
            for chunk in chunks:
                doc_text = chunk.text
                if chunk.context_before:
                    doc_text = chunk.context_before + " " + doc_text
                if chunk.context_after:
                    doc_text = doc_text + " " + chunk.context_after
                
                chunk_documents.append(LangchainDocument(page_content=doc_text))
                chunk_mapping[len(chunk_documents) - 1] = chunk
            
            # Create vector store
            vector_store = FAISS.from_documents(chunk_documents, self.embeddings)
            
            # Search
            search_results = vector_store.similarity_search_with_score(query, k=30)
            
            for doc, score in search_results:
                # Convert distance to similarity
                similarity = 1.0 - (score / 2.0) if score <= 2.0 else 0.0
                
                if similarity >= 0.1:  # Minimum threshold
                    doc_index = chunk_documents.index(doc)
                    chunk = chunk_mapping[doc_index]
                    
                    results.append({
                        'type': 'document_chunk',
                        'source': 'document',
                        'chunk': chunk,
                        'document': chunk.document,
                        'score': similarity,
                        'match_type': 'semantic',
                        'match_reason': f'Document semantic match: {similarity:.3f}',
                        'text_content': chunk.text,
                        'source_info': {
                            'document_title': chunk.document.title,
                            'document_type': chunk.document.document_type,
                            'page_number': chunk.page_number,
                            'chunk_index': chunk.chunk_index
                        }
                    })
            
        except Exception as e:
            logger.error(f"❌ Semantic chunk search error: {str(e)}")
        
        return results
    
    def _keyword_search_qa_entries(self, terms: List[str]) -> List[Dict]:
        """Keyword search on QA entries"""
        results = []
        
        try:
            # Build query
            query = Q()
            for term in terms:
                query |= (
                    Q(question__icontains=term) |
                    Q(answer__icontains=term) |
                    Q(keywords__icontains=term) |
                    Q(sku__icontains=term)
                )
            
            entries = QAEntry.objects.filter(query).distinct()
            
            for entry in entries:
                # Calculate relevance score
                score = self._calculate_keyword_score(entry, terms)
                
                results.append({
                    'type': 'qa_entry',
                    'source': 'qa_database',
                    'entry': entry,
                    'score': score * 0.7,  # Lower than semantic scores
                    'match_type': 'keyword',
                    'match_reason': f'Keyword match: {", ".join(terms)}',
                    'text_content': f"Q: {entry.question}\nA: {entry.answer}",
                    'source_info': {
                        'sku': entry.sku,
                        'category': entry.category
                    }
                })
            
        except Exception as e:
            logger.error(f"❌ Keyword QA search error: {str(e)}")
        
        return results
    
    def _keyword_search_documents(self, terms: List[str], documents) -> List[Dict]:
        """Keyword search on documents and chunks"""
        results = []
        
        try:
            # Search in document metadata
            doc_query = Q()
            for term in terms:
                doc_query |= (
                    Q(title__icontains=term) |
                    Q(extracted_text__icontains=term) |
                    Q(tags__icontains=term) |
                    Q(category__icontains=term)
                )
            
            matching_docs = documents.filter(doc_query)
            
            for doc in matching_docs:
                # Get best chunks from this document
                chunks = TextChunk.objects.filter(document=doc)
                
                for chunk in chunks:
                    chunk_score = 0
                    for term in terms:
                        if term.lower() in chunk.text.lower():
                            chunk_score += 1
                    
                    if chunk_score > 0:
                        score = min(chunk_score / len(terms), 1.0) * 0.6  # Lower than semantic
                        
                        results.append({
                            'type': 'document_chunk',
                            'source': 'document',
                            'chunk': chunk,
                            'document': doc,
                            'score': score,
                            'match_type': 'keyword',
                            'match_reason': f'Document keyword match: {chunk_score} terms',
                            'text_content': chunk.text,
                            'source_info': {
                                'document_title': doc.title,
                                'document_type': doc.document_type,
                                'page_number': chunk.page_number,
                                'chunk_index': chunk.chunk_index
                            }
                        })
            
        except Exception as e:
            logger.error(f"❌ Keyword document search error: {str(e)}")
        
        return results
    
    def _calculate_keyword_score(self, entry: QAEntry, terms: List[str]) -> float:
        """Calculate keyword relevance score for QA entry"""
        text_fields = {
            'sku': entry.sku,
            'question': entry.question,
            'answer': entry.answer,
            'keywords': entry.keywords or '',
            'category': entry.category or ''
        }
        
        field_weights = {
            'sku': 2.0,
            'question': 1.5,
            'answer': 1.0,
            'keywords': 1.2,
            'category': 0.8
        }
        
        total_score = 0
        max_possible = 0
        
        for term in terms:
            term_lower = term.lower()
            term_score = 0
            
            for field_name, field_value in text_fields.items():
                if field_value:
                    count = field_value.lower().count(term_lower)
                    term_score += count * field_weights[field_name]
            
            total_score += term_score
            max_possible += max(field_weights.values())
        
        return min(total_score / max_possible, 1.0) if max_possible > 0 else 0.0
    
    def _has_relevant_chunks(self, query: str) -> bool:
        """Check if we have relevant document chunks for RAG"""
        return TextChunk.objects.exists()
    
    def _generate_rag_answer(self, query: str, search_results: List[Dict]) -> Dict:
        """Generate answer using RAG with ChatGLM"""
        try:
            if not self.chatglm_client:
                return {'answer': '', 'context': ''}
            
            # Select best results for context
            context_items = []
            max_context_items = 8
            
            # Prioritize high-scoring results
            sorted_results = sorted(search_results, key=lambda x: x['score'], reverse=True)
            
            for result in sorted_results[:max_context_items]:
                if result['score'] >= 0.3:  # Only use high-quality results
                    source_info = result['source_info']
                    
                    if result['type'] == 'qa_entry':
                        context = f"[QA Entry - SKU: {source_info['sku']}]\n{result['text_content']}"
                    else:
                        context = f"[Document: {source_info['document_title']} - {source_info['document_type'].upper()}"
                        if source_info.get('page_number'):
                            context += f", Page {source_info['page_number']}"
                        context += f"]\n{result['text_content']}"
                    
                    context_items.append(context)
            
            if not context_items:
                return {'answer': '', 'context': ''}
            
            # Prepare context
            context_text = "\n\n---\n\n".join(context_items)
            
            # Create prompt
            prompt = self._create_rag_prompt(query, context_text)
            
            # Generate answer
            response = self.chatglm_client.chat.completions.create(
                model="glm-4-flash",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=1024
            )
            
            generated_answer = response.choices[0].message.content
            
            logger.info(f"✅ RAG answer generated for query: {query[:50]}...")
            
            return {
                'answer': generated_answer,
                'context': context_text
            }
            
        except Exception as e:
            logger.error(f"❌ RAG generation error: {str(e)}")
            return {'answer': '', 'context': ''}
    
    def _create_rag_prompt(self, query: str, context: str) -> str:
        """Create optimized prompt for RAG generation"""
        
        # Detect query intent
        intent = self.query_processor.get_query_intent(query)
        
        # Base system message
        system_msg = """You are an intelligent assistant that helps users find information about products, troubleshooting, and technical questions. You have access to both structured Q&A data and document content."""
        
        # Intent-specific instructions
        intent_instructions = {
            'installation': "Focus on step-by-step installation procedures and requirements.",
            'troubleshooting': "Provide systematic troubleshooting steps and common solutions.",
            'information': "Give comprehensive and accurate product information.",
            'maintenance': "Offer detailed maintenance procedures and schedules.",
            'parts': "Provide specific part information, compatibility, and specifications.",
            'general': "Answer comprehensively using all available information."
        }
        
        instruction = intent_instructions.get(intent, intent_instructions['general'])
        
        prompt = f"""{system_msg}

{instruction}

Based on the following context information, please answer the user's question. If the context doesn't contain enough information to fully answer the question, say so and provide what information is available.

CONTEXT:
{context}

USER QUESTION: {query}

Please provide a comprehensive answer based on the context above. If you reference specific information, indicate which source it comes from (QA Entry with SKU, or Document name). If the context is insufficient, clearly state what information is missing."""

        return prompt
    
    def _rank_and_limit_results(self, results: List[Dict], max_results: int) -> List[Dict]:
        """Rank and limit search results"""
        # Remove duplicates based on content
        seen_content = set()
        unique_results = []
        
        for result in results:
            content_hash = hash(result['text_content'][:200])  # Hash first 200 chars
            if content_hash not in seen_content:
                seen_content.add(content_hash)
                unique_results.append(result)
        
        # Sort by score
        sorted_results = sorted(unique_results, key=lambda x: x['score'], reverse=True)
        
        # Limit results
        return sorted_results[:max_results]
    
    def _log_enhanced_query(self, original_query: str, processed_query: str, 
                           query_type: str, document_types: List[str], 
                           use_rag: bool, total_results: int, rag_context: str,
                           generated_answer: str, user_ip: str, user_agent: str,
                           response_time: float) -> SemanticQuery:
        """Log enhanced query with RAG information"""
        try:
            query_log = SemanticQuery.objects.create(
                query_text=original_query,
                processed_query=processed_query,
                query_type=query_type,
                document_types_searched=document_types,
                use_rag=use_rag,
                total_results=total_results,
                rag_context_used=rag_context,
                generated_answer=generated_answer,
                user_ip=user_ip,
                user_agent=user_agent or '',
                response_time=response_time
            )
            
            return query_log
            
        except Exception as e:
            logger.error(f"❌ Failed to log query: {str(e)}")
            return None
    
    def _log_query_matches(self, query_log: SemanticQuery, results: List[Dict]):
        """Log query matches for both QA entries and document chunks"""
        if not query_log:
            return
        
        try:
            for i, result in enumerate(results):
                if result['type'] == 'qa_entry':
                    QueryMatch.objects.create(
                        query=query_log,
                        qa_entry=result['entry'],
                        relevance_score=result['score'],
                        match_reason=result['match_reason'],
                        rank_position=i + 1
                    )
                elif result['type'] == 'document_chunk':
                    QueryMatch.objects.create(
                        query=query_log,
                        text_chunk=result['chunk'],
                        relevance_score=result['score'],
                        match_reason=result['match_reason'],
                        rank_position=i + 1
                    )
                    
        except Exception as e:
            logger.error(f"❌ Failed to log query matches: {str(e)}")